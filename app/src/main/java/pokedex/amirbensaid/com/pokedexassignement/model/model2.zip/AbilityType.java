package afinal.amirbensaid.com.afinal.model;

public class AbilityType {

    /**
     * name : imposter
     * url : https://pokeapi.co/api/v2/ability/150/
     */

    private String name;
    private String url;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
