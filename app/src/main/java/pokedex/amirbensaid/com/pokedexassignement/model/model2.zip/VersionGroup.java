package afinal.amirbensaid.com.afinal.model;

public class VersionGroup {

    /**
     * name : ultra-sun-ultra-moon
     * url : https://pokeapi.co/api/v2/version-group/18/
     */

    private String name;
    private String url;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
