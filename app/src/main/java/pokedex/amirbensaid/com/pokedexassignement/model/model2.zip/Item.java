package afinal.amirbensaid.com.afinal.model;

public class Item {

    /**
     * name : metal-powder
     * url : https://pokeapi.co/api/v2/item/234/
     */

    private String name;
    private String url;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
